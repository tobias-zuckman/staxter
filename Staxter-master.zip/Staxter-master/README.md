# Spring Boot Hello from Staxter
Spring Boot service for saying Hello !
