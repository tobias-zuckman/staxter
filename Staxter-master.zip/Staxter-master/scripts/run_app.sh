#!/bin/bash
mvn clean spring-boot:run
